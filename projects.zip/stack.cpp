#include <iostream>
#include <deque>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("Ain.txt");
#define cin fin

string num2str(int n)
{
	if(n==0)
		return "0";
	int s=0;
	string x;
	if(n<0)
		s=1;
	while(n)
	{
		x+=n%10+'0';
		n/=10;
	}
	string temp;
	for(int i=x.size()-1;i>=0;i--)
	{
		temp+=x[i];	
	}
	return temp;
}

class stack
{
	private :
		vector<int> a;
	public :
		void push(int k)
		{
			a.push_back(k);
		}
		void pop()
		{
			a.pop_back();
		}
		int size()
		{
			return a.size();
		}
		int get()
		{
			return a[a.size()-1];
		}
		void print()
		{
			stack s;
			s=*this;
			string temp;
			for(int i=0;i<a.size();i++)
			{
				temp=num2str(s.get())+" "+temp;
				s.pop();
			}
			cout<<temp<<endl;
		}
};

class que
{
	private :
		deque<int> a;
	public :
		void push(int k)
		{
			a.push_back(k);
		}
		void pop()
		{
			a.pop_front();
		}
		int size()
		{
			return a.size();
		}
		int get()
		{
			return a[0];
		}
};

int main()
{
	stack s;
	que q;
	int n , m;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int temp;
		cin>>temp;
		s.push(temp);
	}
	cin>>m;
	for(int i=0;i<n;i++)
	{
		if(s.get()!=m)
			q.push(s.get());
		s.pop();
	}
	n=q.size();
	for(int i=0;i<n;i++)
	{
		s.push(q.get());
		q.pop();
	}
	for(int i=0;i<n;i++)
	{
		q.push(s.get());
		s.pop();
	}
	for(int i=0;i<n;i++)
	{
		s.push(q.get());
		q.pop();
	}
	s.print();
	return 0;
}
