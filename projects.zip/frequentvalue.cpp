#include<iostream>
#include<algorithm>
using namespace std;
struct node{int rg,lf,mx,rgmax,lfmax;};
node tree[1000000];
int arr[1000000],Max;
void treemake(int i,int j,int t)
{
	tree[t].rg=j;
	tree[t].lf=i;
	if(i==j)
	{
		tree[t].mx=tree[t].rgmax=tree[t].lfmax=1;
		return;
	}
	treemake(i,(i+j)/2,2*t);
	treemake((i+j)/2+1,j,2*t+1);
	if(tree[t*2].lfmax==tree[2*t].rg-tree[2*t].lf+1 && arr[tree[t*2].rg]==arr[tree[2*t+1].lf])
		tree[t].lfmax=tree[2*t].lfmax+tree[2*t+1].lfmax;
	else
		tree[t].lfmax=tree[2*t].lfmax;
	if(tree[t*2+1].rgmax==tree[2*t+1].rg-tree[2*t+1].lf+1 && arr[tree[2*t].rg]==arr[tree[2*t+1].lf])
		tree[t].rgmax=tree[2*t].rgmax+tree[2*t+1].rgmax;
	else
		tree[t].rgmax=tree[2*t+1].rgmax;
	if(arr[tree[2*t].rg]==arr[tree[2*t+1].lf])
		tree[t].mx=tree[2*t].rgmax+tree[2*t+1].lfmax;
	tree[t].mx=max(max(tree[2*t].mx,tree[2*t+1].mx),tree[t].mx);
}
void query(int i,int j,int t)
{
	if(i==tree[t].lf && tree[t].rg==j)
	{
		Max=max(tree[t].mx,Max);
		return;
	}
	if(i>=tree[2*t+1].lf)
		query(i,j,2*t+1);
	else if(j<=tree[2*t].rg)
		query(i,j,2*t);
	else
	{
		query(tree[2*t+1].lf,j,2*t+1);
		query(i,tree[2*t].rg,2*t);
		if(arr[tree[2*t].rg]==arr[tree[2*t+1].lf])
			Max=max(Max,min(tree[2*t].rgmax,tree[t*2].rg-i+1)+min(tree[2*t+1].lfmax,j-tree[2*t+1].lf+1));
	}
}
int main()
{
	int n,q;
	cin>>n>>q;
	for(int i=1;i<=n;i++)
		cin>>arr[i];
	treemake(1,n,1);
	for(int i=0;i<q;i++)
	{
		Max=0;
		int a,b;
		cin>>a>>b;
		query(a,b,1);
		cout<<Max<<endl;
	}
	return 0;
}