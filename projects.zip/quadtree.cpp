#include<iostream>
#include<string>
#include<cmath>
using namespace std;
string s;
int p;
int counter(int h)
{
	int ans=0;
	if(s[p]=='f')
		ans=1024/(int)pow(4,h),p++;
	else if(s[p]=='e')p++;
	else if(++p)
		for(int i=0;i<4;i++)
			ans+=counter(h+1);
	return ans;
}
int main()
{
	cin>>s;
	cout<<counter(0)<<endl;
	return 0;
}