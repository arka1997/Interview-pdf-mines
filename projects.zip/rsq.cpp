#include<iostream>
#include<cstdio>
using namespace std;
#define right rrrr
#define left llll
const int M=1e6;
const int INF=1e9;
int n,arr[M],left,right,maxi;
struct node{int a,b,mxl,mxr,mx,sm;};
node tree[M];
void build(int i,int j,int t)
{
	tree[t].a=i;
	tree[t].b=j;
	if(i==j)
	{
		tree[t].mx=tree[t].mxl=tree[t].mxr=tree[t].sm=arr[i];
		return;
	}
	build(i,(i+j)/2,2*t);
	build((i+j)/2+1,j,2*t+1);
	tree[t].mx=max(tree[2*t].mxr+tree[2*t+1].mxl,max(tree[2*t].mx,tree[2*t+1].mx));
	tree[t].mxl=max(tree[2*t].mxl,tree[2*t].sm+tree[2*t+1].mxl);
	tree[t].mxr=max(tree[2*t+1].mxr,tree[2*t].mxr+tree[2*t+1].sm);
	tree[t].sm=tree[2*t].sm+tree[2*t+1].sm;
}
int find(int i,int j,int t)
{
	if(tree[t].a==tree[t].b)
		return t;
	if(j<=tree[2*t].b)
		return find(i,j,2*t);
	if(i>=tree[2*t+1].a)
		return find(i,j,2*t+1);
	return t;
}
void rquery(int j,int t)
{
	if(j<tree[t].a)
		return;
	if(tree[t].b==j)
	{
		maxi=max(max(right+tree[t].mxr,tree[t].mx),maxi);
		right=max(right+tree[t].sm,tree[t].mxl);
		return;
	}
	rquery(j,2*t+1);
	rquery(min(j,tree[2*t].b),2*t);
}
void lquery(int i,int t)
{
	if(i>tree[t].b)
		return;
	if(tree[t].a==i)
	{
		maxi=max(max(left+tree[t].mxl,tree[t].mx),maxi);
		left=max(left+tree[t].sm,tree[t].mxr);
		return;
	}
	lquery(i,2*t);
	lquery(max(i,tree[2*t+1].a),2*t+1);
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&arr[i]);
	build(1,n,1);
	int q;
	cin>>q;
	while(q--)
	{
		int i,j;
		scanf("%d%d",&i,&j);
		int k=find(i,j,1);
		left=right=maxi=INF*(-1);
		if(tree[k].a==tree[k].b)
			printf("%d\n",tree[k].mx);
		else
		{
			rquery(j,k*2+1);
			lquery(i,2*k);
			printf("%d\n",max(maxi,right+left));
		}
	}
	return 0;
}