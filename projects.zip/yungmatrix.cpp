#include<iostream>
using namespace std;
const int M=1000;
int a,b,yung[M][M],n;
void find(int i,int j,int k)
{
	if(yung[i][j]==k)
	{
		a=i;
		b=j;
		return;
	}
	if(yung[i][j]>k)
		find(i,j-1,k);
	else
		find(i+1,j,k);
}
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			cin>>yung[i][j];
	find(1,n,5);
	cout<<a<<" "<<b<<endl;
	return 0;
}